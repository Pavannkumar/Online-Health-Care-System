﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

public partial class _2098_health_usubscribe1 : System.Web.UI.Page
{
    SqlConnection con;
    SqlConnection con1;
    String s = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);

        Label2.Text = Session["name"].ToString();
        Label4.Text = Session["mobile"].ToString();
        Label3.Text = Session["logname"].ToString();
        Label6.Text = DateTime.Now.Date.ToShortDateString();
        Label6.Text = DateTime.Now.Date.ToShortDateString();


        s = Request.QueryString.Get(0);
        if(s.Equals("1"))
        {
            Label1.Text = s;
            Label5.Text = "499";
            Label7.Text = DateTime.Now.Date.AddDays(30).ToShortDateString();
        }
        else if (s.Equals("2"))
        {
            Label1.Text = s;
            Label5.Text = "999";
            Label7.Text = DateTime.Now.Date.AddDays(180).ToShortDateString();

        }
        else if (s.Equals("3"))
        {
            Label1.Text = s;
            Label5.Text = "1999";
            Label7.Text = DateTime.Now.Date.AddDays(365).ToShortDateString();

        }



    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            String  eid = Session["logname"].ToString();
          
                s = "insert into subscription values(@a,@b,@c,@d,@e,@f)";
                SqlCommand cmd1 = new SqlCommand(s, con);



                cmd1 = new SqlCommand(s, con);

                cmd1.Parameters.Add("@a", eid);
                cmd1.Parameters.Add("@b", Label1.Text);
                cmd1.Parameters.Add("@c", Label6.Text);
                cmd1.Parameters.Add("@d", Label7.Text);
              cmd1.Parameters.Add("@e", Label5.Text);
              cmd1.Parameters.Add("@f", "ACTIVE");



                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert(' Subscribed Successfully');window.location='userpage.aspx';</script>");


                //TextBox1.Text = "";
                //TextBox2.Text = "";
                //txtUsername.Text = "";

                //txtPassword.Text = "";
                ////TextBox7.Text = "";


                ////TextBox8.Text = "";
                ////TextBox9.Text = "";

            

        }
        catch (Exception ex)
        {

            Label8.Text = ex.ToString();

        }
    }
}