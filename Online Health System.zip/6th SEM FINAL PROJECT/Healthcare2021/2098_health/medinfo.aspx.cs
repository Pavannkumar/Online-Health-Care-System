﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _2098_health_medinfo : System.Web.UI.Page
{


    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //protected void Button1_Click(object sender, EventArgs e)
    //{
       
    //}
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            con = new SqlConnection(strcon);


            string s = "select * from addmedicine where forsymptoms=" + "'" + txtUsername.Text + "'" ;


            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;
            // String name = "", mobile = "", address = "";
            while (reader.Read())
            {
                ctr++;
                //name = reader.GetString(1);
                //mobile = reader.GetString(2);
                //address = reader.GetString(7);
            }
            reader.Close();
            con.Close();
            if (ctr == 1)
            {
                // Label1.Text = "success";
              //  Session["logname"] = txtUsername.Text.Trim();
                //Session["name"] = name;
                //Session["address"] = address;
                //Session["mobile"] = mobile;
                Response.Redirect("medinfo1.aspx?para="+txtUsername.Text);
                //Response.Write("<script>alert('Found ');window.location='medinfo.aspx';</script>");
                // Response.Redirect("adminhomepage.aspx");
            }
            else
            {
                Response.Write("<script>alert('Not Found ');window.location='login.aspx';</script>");
            }


        }
        catch (Exception ex)
        {

            lblMessage.Text = ex.ToString();
            // Label1.Text = ex.ToString();
        }

        Response.Write("<script>alert('Search Details Not Found ');window.location='medinfo.aspx';</script>");
    }
}