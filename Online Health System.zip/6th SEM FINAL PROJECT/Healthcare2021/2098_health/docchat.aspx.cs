﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class _2098_health_docchat : System.Web.UI.Page
{


    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Label2.Text = DateTime.Now.ToLongDateString();

            string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            con = new SqlConnection(strcon);

            string id = Session["id"].ToString();
            string s = "select * from consultdoc where doctorname="+"'" + id + "'"+" and not status='Replied'";


            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;

            while (reader.Read())
            {

                ctr++;



            }
            reader.Close();
            con.Close();


            if (ctr > 0)
            {
                /////////////////////

                // string str11 = "select * from emp  where not email=" + "'" + ln + "'";
                s = "select * from consultdoc where doctorname=" + "'" + id + "'" + " and not status='Replied'";



                //ownerid,fname,phone from owner WHERE ownerid =" + "'" + txtowner.Text + "'";
                con.Open();
                SqlCommand cmd2 = new SqlCommand(s, con);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter();
                da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();

                con.Close();
            }
            else
            {
                Label1.Text = "Sorry No Queries found";
            }

            ////////////////////////////



             s = "select * from consultdoc where doctorname=" + "'" + id + "'" + " and not status='Replied'";


            con.Open();

            SqlCommand cmd3 = new SqlCommand(s, con);
            SqlDataReader reader3;
            reader3 = cmd3.ExecuteReader();
          
            // String name = "", mobile = "", address = "";
            while (reader3.Read())
            {
                DropDownList1.Items.Add(reader3.GetString(2));
            }
            reader3.Close();
            con.Close();
           


        }
        catch (Exception ex)
        {

          
            Label1.Text = ex.ToString();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            string s = "update consultdoc   set reply=@a,dateofreply=@c,status='Replied' where patientEmailid=@b";
                SqlCommand cmd11 = new SqlCommand(s, con);
                cmd11.Parameters.Add("@a", TextBox2.Text);
                cmd11.Parameters.Add("@b", DropDownList1.Text);
                cmd11.Parameters.Add("@c", Label2.Text);
             
                con.Open();
                cmd11.ExecuteNonQuery();
                con.Close();
            
                Response.Write("<script>alert('Replied  Successfully ');window.location='doctorpage.aspx';</script>");
        }
        catch(Exception ex)
        {
            Label1.Text = ex.ToString();

        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

       // Image1.ImageUrl = "vicks.jpg";

        try
        {


            // string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            // con = new SqlConnection(strcon);

            string id = Session["id"].ToString();
            string s = "select * from consultdoc where doctorname=" + "'" + id + "'";




            s = "select * from consultdoc where doctorname=" + "'" + id + "'";


            con.Open();

            SqlCommand cmd3 = new SqlCommand(s, con);
            SqlDataReader reader3;
            reader3 = cmd3.ExecuteReader();

            // String name = "", mobile = "", address = "";
            while (reader3.Read())
            {
                Image1.ImageUrl = reader3.GetString(3);

                //Label1.Text = reader3.GetString(3);
            }
            reader3.Close();
            con.Close();



        }
        catch (Exception ex)
        {


            Label1.Text = ex.ToString();
        }
    }
}