﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class _2098_health_aadddoctors : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {

        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
          
            string s = "select * from doctor  where registration_id="+"'"+TextBox1.Text+"'" +" and u="+"'"+TextBox8.Text+"'";
            con.Open();

            SqlCommand cmd11 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd11.ExecuteReader();
            int ctr = 100;
            while (reader.Read())
            {
                ctr++;

            }
            reader.Close();
            con.Close();
          


            //////////////////////////
            if (ctr == 100)
            {
                s = "insert into doctor values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j,@k,@l,@m)";
                SqlCommand cmd1 = new SqlCommand(s, con);



                cmd1 = new SqlCommand(s, con);

                cmd1.Parameters.Add("@a", TextBox1.Text);
                cmd1.Parameters.Add("@b", TextBox2.Text);
                cmd1.Parameters.Add("@c", TextBox3.Text);
                cmd1.Parameters.Add("@d", TextBox4.Text);
                cmd1.Parameters.Add("@e", TextBox5.Text);
                cmd1.Parameters.Add("@f", DropDownList1.Text);
                cmd1.Parameters.Add("@g", DropDownList2.Text);
                cmd1.Parameters.Add("@h", TextBox6.Text);
                cmd1.Parameters.Add("@i", TextBox7.Text);
                cmd1.Parameters.Add("@j", DropDownList3.Text);
                cmd1.Parameters.Add("@k", TextBox8.Text);
                cmd1.Parameters.Add("@l", TextBox9.Text);
                cmd1.Parameters.Add("@m", FileUpload1.FileName  );
             

                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert(' Registrered Successfully');window.location='adminpage.aspx';</script>");

                TextBox6.Text = "";
                TextBox1.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";

                TextBox5.Text = "";
                TextBox7.Text = "";


                TextBox8.Text = "";
                TextBox9.Text = "";

            }

            else
            {
                Response.Write("<script>alert('Already Registrered ');window.location='adminpage.aspx';</script>");
            }
        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
    }
}