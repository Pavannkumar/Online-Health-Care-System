﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

public partial class _2098_health_ubooktest : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["name"].ToString();
        Label4.Text = Session["logname"].ToString();

        Label3.Text=Session["mobile"] .ToString();


        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {

            string dt = DateTime.Now.ToLongDateString();
            string s = "insert into booktest values(@a,@b,@c,@d,@e,@f)";
            SqlCommand cmd1 = new SqlCommand(s, con);



            cmd1 = new SqlCommand(s, con);

            cmd1.Parameters.Add("@a", DropDownList1.Text);
            cmd1.Parameters.Add("@b", Label2.Text);
            cmd1.Parameters.Add("@c", Label4.Text);
            cmd1.Parameters.Add("@d", Label3.Text);
            cmd1.Parameters.Add("@e", Label5.Text);
            cmd1.Parameters.Add("@f", TextBox4.Text);
           



            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert(' Appointment Booked  Successfully');window.location='userpage.aspx';</script>");


            //TextBox1.Text = "";
            //TextBox2.Text = "";
            //txtUsername.Text = "";

            //txtPassword.Text = "";
            //TextBox7.Text = "";


            //TextBox8.Text = "";
            //TextBox9.Text = "";


        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
    }
}