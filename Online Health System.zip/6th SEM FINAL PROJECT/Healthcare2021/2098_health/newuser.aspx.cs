﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

public partial class _2098_health_newuser : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {

            string s = "select * from register  where emailid=" + "'" + TextBox1.Text + "'";
            con.Open();

            SqlCommand cmd11 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd11.ExecuteReader();
            int ctr = 100;
            while (reader.Read())
            {
                ctr++;

            }
            reader.Close();
            con.Close();



            //////////////////////////
            if (ctr == 100)
            {
                s = "insert into register values(@a,@b,@c,@d)";
                SqlCommand cmd1 = new SqlCommand(s, con);



                cmd1 = new SqlCommand(s, con);

                cmd1.Parameters.Add("@a", txtUsername.Text);
                cmd1.Parameters.Add("@b", txtPassword.Text);
                cmd1.Parameters.Add("@c", TextBox1.Text);
                cmd1.Parameters.Add("@d", TextBox2.Text);
                


                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert(' Registrered Successfully');window.location='adminpage.aspx';</script>");

              
                TextBox1.Text = "";
                TextBox2.Text = "";
              txtUsername.Text = "";

                txtPassword.Text= "";
                //TextBox7.Text = "";


                //TextBox8.Text = "";
                //TextBox9.Text = "";

            }

            else
            {
                Response.Write("<script>alert('Already Registrered ');window.location='adminpage.aspx';</script>");
            }
        }
        catch (Exception ex)
        {

          lblMessage.Text= ex.ToString();

        }

        //Response.Write("<script>alert('Registratio Success ');window.location='index.html';</script>");
    }
    
}