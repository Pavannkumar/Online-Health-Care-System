﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _2098_health_aaddmed : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {

            string s = "select * from addmedicine  where medicinename=" + "'" + TextBox2.Text + "'" ;
            con.Open();

            SqlCommand cmd11 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd11.ExecuteReader();
            int ctr = 100;
            while (reader.Read())
            {
                ctr++;

            }
            reader.Close();
            con.Close();



            //////////////////////////
            if (ctr == 100)
            {
                s = "insert into addmedicine values(@a,@b,@c,@d)";
                SqlCommand cmd1 = new SqlCommand(s, con);



                cmd1 = new SqlCommand(s, con);

            
                cmd1.Parameters.Add("@a", TextBox2.Text);
                cmd1.Parameters.Add("@b", TextBox3.Text);
            
                cmd1.Parameters.Add("@c", FileUpload1.FileName);
                cmd1.Parameters.Add("@d", TextBox4.Text);


                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert(' Registrered Successfully');window.location='adminpage.aspx';</script>");

               
                TextBox3.Text = "";
                TextBox2.Text = "";


            }

            else
            {
                Response.Write("<script>alert('Already Registrered ');window.location='adminpage.aspx';</script>");
            }
        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }

    }
}