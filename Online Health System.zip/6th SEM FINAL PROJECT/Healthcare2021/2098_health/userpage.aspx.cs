﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class userpage : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {


       // SELECT * from SUBSCRIPTION where dateofexpiry <= '16-08-2021';



        try
        {
            string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            con = new SqlConnection(strcon);

            string cdate = DateTime.Now.ToLongDateString();
            string s = "SELECT * from SUBSCRIPTION where dateofexpiry <= "+"'"+cdate+"'";

//            Response.Write("<script>alert('Active Subscription ');window.location='userpage.aspx';</script>");
            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;
            // String name = "", mobile = "", address = "";
            while (reader.Read())
            {
                ctr++;
              
            }
            reader.Close();
            con.Close();
            if (ctr == 1)
            {
                
               // Response.Write("<script>alert('Active Subscription ');window.location='userpage.aspx';</script>");
                
            }
            else
            {
                ////Response.Write("<script>alert('No Active Subscription ');window.location='userpage.aspx';</script>");
            }


        }
        catch (Exception ex)
        {

            //lblMessage.Text = ex.ToString();
            // Label1.Text = ex.ToString();
        }
    }
}