﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class _2098_health_glogin : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            con = new SqlConnection(strcon);


            string s = "select * from register where emailid=" + "'" + txtUsername.Text + "'" + " and  password=" + "'" + txtPassword.Text + "'";


            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;
             String name = "", mobile = "";//, address = "";
            while (reader.Read())
            {
                ctr++;
                name = reader.GetString(0);
                mobile = reader.GetString(1);
                //address = reader.GetString(7);
            }
            reader.Close();
            con.Close();
            if (ctr == 1)
            {
                // Label1.Text = "success";
                Session["logname"] = txtUsername.Text.Trim();
                Session["name"] = name;
                //Session["address"] = address;
                Session["mobile"] = mobile;

                Response.Write("<script>alert('Login Success ');window.location='userpage.aspx';</script>");
                // Response.Redirect("adminhomepage.aspx");
            }
            else
            {
                Response.Write("<script>alert('Login Failed ');window.location='glogin.aspx';</script>");
            }


        }
        catch (Exception ex)
        {

            lblMessage.Text = ex.ToString();
            // Label1.Text = ex.ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("newuser.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("forgotpwd.aspx");
    }
}