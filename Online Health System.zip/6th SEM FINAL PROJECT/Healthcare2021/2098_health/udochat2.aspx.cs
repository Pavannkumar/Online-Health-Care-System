﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

public partial class _2098_health_udochat2 : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Request.QueryString.Get(0);

        Label3.Text = Session["name"].ToString();
        Label4.Text = Session["logname"].ToString();

        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);

        try
        {

            string str11 = "select * from consultdoc where patientemailid =" + "'" + Label4.Text + "'";



                //ownerid,fname,phone from owner WHERE ownerid =" + "'" + txtowner.Text + "'";
                con.Open();
                SqlCommand cmd2 = new SqlCommand(str11, con);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter();
                da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();

                con.Close();

        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
        
       


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {

          string dt=DateTime.Now.ToLongDateString();
              string  s = "insert into consultdoc values(@a,@b,@c,@d,@e,@f,@g,@h,@i)";
                SqlCommand cmd1 = new SqlCommand(s, con);



                cmd1 = new SqlCommand(s, con);

                cmd1.Parameters.Add("@a", Label2.Text);
                cmd1.Parameters.Add("@b", Label3.Text);
                cmd1.Parameters.Add("@c", Label4.Text);
                cmd1.Parameters.Add("@d", FileUpload1.FileName);
             cmd1.Parameters.Add("@e", TextBox1.Text);
                cmd1.Parameters.Add("@f", dt);
                cmd1.Parameters.Add("@g", "");
                cmd1.Parameters.Add("@h", "");
             cmd1.Parameters.Add("@i", "Pending");



                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert(' Message Sent Successfully');window.location='userpage.aspx';</script>");


                //TextBox1.Text = "";
                //TextBox2.Text = "";
                //txtUsername.Text = "";

                //txtPassword.Text = "";
                //TextBox7.Text = "";


                //TextBox8.Text = "";
                //TextBox9.Text = "";

           
        }
        catch (Exception ex)
        {

            Label1.Text = ex.ToString();

        }
    }
}