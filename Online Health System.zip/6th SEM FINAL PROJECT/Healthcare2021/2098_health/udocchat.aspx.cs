﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _2098_health_udocchat : System.Web.UI.Page
{

    SqlConnection con;
    SqlConnection con1;
    string eid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
         eid = Session["logname"].ToString();
        // SELECT * from SUBSCRIPTION where dateofexpiry <= '16-08-2021';
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        con = new SqlConnection(strcon);



     try{
       
          

            string s = "select distinct(edept) from doctor ";// where emailid=" + "'" + txtUsername.Text + "'" + " and  password=" + "'" + txtPassword.Text + "'";


            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;
            String name = "", mobile = "";//, address = "";
            while (reader.Read())
            {

                DropDownList1.Items.Add(reader.GetString(0));
                //ctr++;
                //name = reader.GetString(0);
                //mobile = reader.GetString(1);
                ////address = reader.GetString(7);

            }
            reader.Close();
            con.Close();
            //if (ctr == 1)
            //{
            //    // Label1.Text = "success";
            //    Session["logname"] = txtUsername.Text.Trim();
            //    Session["name"] = name;
            //    //Session["address"] = address;
            //    Session["mobile"] = mobile;

            //    Response.Write("<script>alert('Login Success ');window.location='userpage.aspx';</script>");
            //    // Response.Redirect("adminhomepage.aspx");
            //}
            //else
            //{
            //    Response.Write("<script>alert('Login Failed ');window.location='glogin.aspx';</script>");
            //}


        }
        catch (Exception ex)
        {

            // lblMessage.Text = ex.ToString();
            // Label1.Text = ex.ToString();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        try
        {

            string cdate = DateTime.Now.ToLongDateString();
            string s = "SELECT * from SUBSCRIPTION where dateofexpiry <= " + "'" + cdate + "'" + "and patientEmail=" + "'" + eid + "'";


            con.Open();

            SqlCommand cmd1 = new SqlCommand(s, con);
            SqlDataReader reader;
            reader = cmd1.ExecuteReader();
            int ctr = 0;

            while (reader.Read())
            {
                ctr++;

            }
            reader.Close();
            con.Close();
            if (ctr == 1)
            {
                Response.Redirect("udochat1.aspx?dept=" + DropDownList1.Text);

                // Response.Write("<script>alert('Active Subscription ');window.location='userpage.aspx';</script>");

            }
            else
            {
                Response.Write("<script>alert('No Active Subscription ');window.location='userpage.aspx';</script>");
            }
        }
        catch (Exception ex)
        {

            // lblMessage.Text = ex.ToString();
            // Label1.Text = ex.ToString();
        }
      
    }
}